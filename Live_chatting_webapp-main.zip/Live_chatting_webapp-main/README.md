# Live_chatting_webapp
It is a live chat app web application built with Django that allows users to participate in anonymous chat rooms. Users can enter a chat room, send messages, and receive messages from other participants in real-time. The app utilizes Django Channels for WebSocket communication, ensuring instant message delivery.
