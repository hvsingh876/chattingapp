# chating-website-using-Django
This is a chating website Using Django , django channels

Watch Tutorial here - https://youtu.be/ZIlQIhF-w_k

It is a basic chatting website where anyone can join any room and chat with other who available in that room.
